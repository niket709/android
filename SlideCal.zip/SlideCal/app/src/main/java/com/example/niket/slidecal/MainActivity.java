package com.example.niket.slidecal;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.view.View.OnClickListener;
import android.widget.TextView;
import android.widget.Toast;
import java.lang.Math;

import static com.example.niket.slidecal.R.id.log;
import static java.lang.Boolean.TRUE;
import static java.lang.Math.cos;
import static java.lang.Math.log;
import static java.lang.Math.log10;
import static java.lang.Math.sin;
import static java.lang.Math.tan;

public class MainActivity extends AppCompatActivity implements OnClickListener {

    @Override
    protected void onCreate(Bundle savedInstanceState)  {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Button cl= (Button) findViewById(R.id.clear);
        cl.setOnClickListener(this);
        Button sinb= (Button) findViewById(R.id.sin);
        sinb.setOnClickListener(this);
        Button cosb= (Button) findViewById(R.id.cos);
        cosb.setOnClickListener(this);
        Button tanb= (Button) findViewById(R.id.tan);
        tanb.setOnClickListener(this);
        Button c1= (Button) findViewById(R.id.b1);
        c1.setOnClickListener(this);
        Button c2= (Button) findViewById(R.id.b2);
        c2.setOnClickListener(this);
        Button c3= (Button) findViewById(R.id.b3);
        c3.setOnClickListener(this);
        Button c4= (Button) findViewById(R.id.b4);
        c4.setOnClickListener(this);
        Button c5= (Button) findViewById(R.id.b5);
        c5.setOnClickListener(this);
        Button c6= (Button) findViewById(R.id.b6);
        c6.setOnClickListener(this);
        Button c7= (Button) findViewById(R.id.b7);
        c7.setOnClickListener(this);
        Button c8= (Button) findViewById(R.id.b8);
        c8.setOnClickListener(this);
        Button c9= (Button) findViewById(R.id.b9);
        c9.setOnClickListener(this);
        Button decb= (Button) findViewById(R.id.dec);
        decb.setOnClickListener(this);
        Button openb= (Button) findViewById(R.id.open);
        openb.setOnClickListener(this);
        Button closeb= (Button) findViewById(R.id.close);
        closeb.setOnClickListener(this);
        Button lnb= (Button) findViewById(R.id.ln);
        lnb.setOnClickListener(this);
        Button logb= (Button) findViewById(log);
        logb.setOnClickListener(this);
        Button equalb= (Button) findViewById(R.id.equal);
        equalb.setOnClickListener(this);
        Button addb= (Button) findViewById(R.id.add);
        addb.setOnClickListener(this);
    }
    boolean pow = false,madd= false;
    @Override
    public void onClick(View v) {

        TextView et = (TextView) findViewById(R.id.et);
        Double a = null,b ,c;
        switch (v.getId()){
            case R.id.add:
                Log.d("Nike","inside add");
                a = Double.parseDouble(et.getText()+"");
                madd = true;
                et.setText(null);
                break;
            case R.id.ln:
                a = Double.parseDouble(et.getText().toString());
                b = log10(a);
                et.setText(String.valueOf(b));
                break;
            case log:
                a = Double.parseDouble(et.getText().toString());
                b = log(a);
                et.setText(String.valueOf(b));
                break;
            case R.id.clear:
                et.setText(null);
                break;
            case R.id.open:
                et.setText(et.getText()+"(");
                break;
            case R.id.close:
                et.setText(et.getText()+")");
                break;z
            case R.id.b1:
                et.setText(et.getText()+"1");
                break;
            case R.id.b2:
                et.setText(et.getText()+"2");
                break;
            case R.id.b3:
                et.setText(et.getText()+"3");
                break;
            case R.id.b4:
                et.setText(et.getText()+"4");
                break;
            case R.id.b5:
                et.setText(et.getText()+"5");
                break;
            case R.id.b6:
                et.setText(et.getText()+"6");
                break;
            case R.id.b7:
                et.setText(et.getText()+"7");
                break;
            case R.id.b8:
                et.setText(et.getText()+"8");
                break;
            case R.id.b9:
                et.setText(et.getText()+"9");
                break;
            case R.id.b0:
                et.setText(et.getText()+"0");
                break;
            case R.id.dec:
                et.setText(et.getText()+".");
                break;
            case R.id.sin:
                a = Double.parseDouble(et.getText().toString());
                b = sin(a);
                et.setText(String.valueOf(b));
                break;
            case R.id.cos:
                a = Double.parseDouble(et.getText().toString());
                b = cos(a);
                et.setText(String.valueOf(b));
                break;
            case R.id.tan:
                a = Double.parseDouble(et.getText().toString());
                b = tan(a);
                et.setText(String.valueOf(b));
                break;
            case R.id.equal:
                Log.d("Nike","Inside Equal1111");
                b = Double.parseDouble(et.getText()+"");
                if (madd == true ){
                    Log.d("Nike","Inside Equal");
                    et.setText(a+b+"");
                    Log.d("Nike","Inside Equal222");
                    madd = false;
                    break;
                }
                break;


            default:
                Toast.makeText(this,"Wrong Input",Toast.LENGTH_SHORT).show();
                break;
        }
    }
}
