package com.example.niket.sqlite;

import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.database.SQLException;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;
import android.widget.Toast;

/**
 * Created by Niket on 14-Jun-17.
 */

public class DBHelper extends SQLiteOpenHelper {
    public static String database_name = "logindatabase";
    public static String table_name = "registration";
    public static String COL_1 = "name";
    public static String COL_2 = "username";
    public static String COL_3 = "password";
    public DBHelper(Context context) {
        super(context, database_name, null, 1);

    }
    public String validate(String name, String pass) {
        String[] colm=new String[]{COL_1,COL_2,COL_3};
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor c= db.query(table_name, colm,null,null, null, null, null);
        String aa="";
        int iname=c.getColumnIndex(COL_2);
        int ipass=c.getColumnIndex(COL_3);
        int i = 0;
        for(c.moveToFirst();! c.isAfterLast();c.moveToNext())
        {
            if((name.equalsIgnoreCase(c.getString(iname))) && (pass.equalsIgnoreCase(c.getString(ipass))))
            {
                aa="aa";
                break;
            }
        }
        return aa;
    }
    public boolean insertdata(String name,String username,String password){
        SQLiteDatabase db=this.getWritableDatabase();
        ContentValues content = new ContentValues();
        content.put(COL_1,name);
        content.put(COL_2,username);
        content.put(COL_3,password);
        long a = db.insert(table_name,null,content);
        if (a != -1){
            return true;
        }
        else{
            return false;
        }
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL(" CREATE TABLE " + table_name+ " (" + COL_1+ " STRING PRIMARY KEY , " + COL_2 +" STRING , "+ COL_3 + " STRING "+" );");
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS "+table_name+" ;");
        onCreate(db);
    }
}
