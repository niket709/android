package com.example.niket.sqlite;

import android.content.Intent;
import android.support.annotation.StringRes;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

public class Main2Activity extends AppCompatActivity {
    EditText password,name,username,retype;
    DBHelper db = new DBHelper(this);
    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);
        name = (EditText) findViewById(R.id.name);
        username = (EditText) findViewById(R.id.username);
        password = (EditText) findViewById(R.id.password);
        retype= (EditText) findViewById(R.id.retypepassword);
        name.setSelection(name.getText().length());
        name.requestFocus();
        username.setSelection(username.getText().length());
        password.setSelection(password.getText().length());
        retype.setSelection(retype.getText().length());

    }
    public void reg (View v){
        String name1,username1,password1, retype1;
        password1 =password.getText().toString();
        retype1 =retype.getText().toString();
        if (name.getText().toString().isEmpty() || username.getText().toString().isEmpty()||password.getText().toString().isEmpty()||retype.getText().toString().isEmpty())
        {
            Toast.makeText(this,"Data can't be blank.",Toast.LENGTH_SHORT).show();
        }
        else if (password1.equals(retype1) == false){
            Toast.makeText(this,"Passwords do not match.",Toast.LENGTH_SHORT).show();
            password.setText(null);
            retype.setText(null);
        }
        else
        {
            name1=name.getText().toString();
            username1=username.getText().toString();
            password1=password.getText().toString();
            boolean b =  db.insertdata(name1,username1,password1);
            if (b== true){
                Toast.makeText(this,"Data Is Updated Successfully.",Toast.LENGTH_SHORT).show();
                Intent intent = new Intent(this,MainActivity.class);
                startActivity(intent);
            }
        }

    }
}
