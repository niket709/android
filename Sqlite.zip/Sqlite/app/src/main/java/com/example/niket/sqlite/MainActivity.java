package com.example.niket.sqlite;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    DBHelper db = new DBHelper(this);
    EditText user,pass;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        user = (EditText) findViewById(R.id.user);
        user.setSelection(user.getText().length());
        user.requestFocus();
        pass = (EditText) findViewById(R.id.pass);
        pass.setSelection(pass.getText().length());
    }
    public void login(View v){
        String search = db.validate(user.getText().toString(),pass.getText().toString());
        if (user.getText().toString().isEmpty() || pass.getText().toString().isEmpty()){
            Toast.makeText(this,"Username or Password can't be blank.",Toast.LENGTH_SHORT).show();
        }
        else if(search.equals("") == true){
            Toast.makeText(this,"User Not Found",Toast.LENGTH_SHORT).show();
        }
        else
        {
            Intent intent=new Intent(this,LoginSuccess.class);
            startActivity(intent);
        }
    }
    public void register(View v){
        Intent intent = new Intent(this,Main2Activity.class);
        startActivity(intent);
    }
}
