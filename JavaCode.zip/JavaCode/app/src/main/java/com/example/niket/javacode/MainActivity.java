package com.example.niket.javacode;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.EditText;
import android.widget.RelativeLayout;
import android.widget.Button;
import android.graphics.Color;
import android.widget.TextView;
import android.content.res.Resources;
import android.util.TypedValue;
public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        RelativeLayout hii = new RelativeLayout(this);
        RelativeLayout.LayoutParams obj = new RelativeLayout.LayoutParams(RelativeLayout.LayoutParams.WRAP_CONTENT,RelativeLayout.LayoutParams.WRAP_CONTENT);
        obj.addRule(RelativeLayout.CENTER_HORIZONTAL);
        obj.addRule(RelativeLayout.CENTER_VERTICAL);
        Button h =new Button(this);
        hii.setBackgroundColor(Color.rgb(00,66,66));
        h.setBackgroundColor(Color.WHITE);
        h.setId('1');
        RelativeLayout.LayoutParams text = new RelativeLayout.LayoutParams(RelativeLayout.LayoutParams.WRAP_CONTENT,RelativeLayout.LayoutParams.WRAP_CONTENT);
        text.addRule(RelativeLayout.ABOVE,h.getId());
        text.addRule(RelativeLayout.CENTER_HORIZONTAL);
        EditText text1 = new EditText(this);
        text1.setId('2');
        Resources r = getResources();
        int px = (int) TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP,200,r.getDisplayMetrics());
        text.setMargins(0,0,0,50);
        text1.setWidth(px);
        RelativeLayout.LayoutParams text2 = new RelativeLayout.LayoutParams(RelativeLayout.LayoutParams.WRAP_CONTENT,RelativeLayout.LayoutParams.WRAP_CONTENT);
        text2.addRule(RelativeLayout.CENTER_HORIZONTAL);
        text2.addRule(RelativeLayout.ABOVE,text1.getId());
        EditText text3=new EditText(this);
        text2.setMargins(0,0,0,50);
        text3.setWidth(px);
        hii.addView(text3,text2);

        h.setText("LOG IN");
        hii.addView(h,obj);
        hii.addView(text1,text);
        setContentView(hii);
    }
}
