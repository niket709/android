package com.example.niket.intentmap;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

    }
    public void Process(View v){

        if (v.getId()==R.id.maps)
        {
            Uri uri = Uri.parse("geo:0,0?q=restaurants");
            Intent intent = new Intent(Intent.ACTION_VIEW, uri);
            intent.setPackage("com.google.android.apps.maps");
Intent chooser= new Intent(Intent.createChooser(intent,"YO"));
            startActivity(chooser);
        }
        if (v.getId()==R.id.market)
        {
            Uri uri = Uri.parse("market://details?id=com.miniclip.eightballpool");
            Intent intent = new Intent(Intent.ACTION_VIEW, uri);
            Intent chooser= new Intent(Intent.createChooser(intent,"YO1"));
            startActivity(chooser);
        }
        if (v.getId()==R.id.email)
        {

            Intent intent = new Intent(Intent.ACTION_SEND);
            intent.setData( Uri.parse("mailto:"));
            String to = "niketrocks2@gmail.com";
            intent.putExtra(Intent.EXTRA_EMAIL,to);
            intent.putExtra(Intent.EXTRA_SUBJECT,"hey");
            intent.putExtra(Intent.EXTRA_TEXT,"cdjdcb");
            intent.setType("text/plain");
            Intent chooser= new Intent(Intent.createChooser(intent,"YO2"));
            startActivity(chooser);
        }
    }


}
